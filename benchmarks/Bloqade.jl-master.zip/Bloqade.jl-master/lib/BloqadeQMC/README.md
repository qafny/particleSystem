# BloqadeQMC

